# Subba Reddy Velpula: Portfolio

Plain HTML, CSS and JavaScript. No build step, no backend.

## Edit your details
Open `script.js` and fill in the `CONFIG` block at the top: email, GitHub, LinkedIn and course dates. Project text, status and repository links are in the `PROJECTS` list. Change `status` to `"Completed"` only when a project is finished.
Put your resume PDF at `assets/resume/resume.pdf`.

## Run locally in VS Code
1. Open the `portfolio` folder in VS Code.
2. Install the **Live Server** extension, right-click `index.html` and choose **Open with Live Server**. (Double-clicking `index.html` also works.)

## Upload to GitHub
```bash
cd portfolio
git init
git add .
git commit -m "Add portfolio website"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-username>.github.io.git
git push -u origin main
```
Create the empty repository on GitHub first. Naming it `<your-username>.github.io` gives you the shortest URL.

## Deploy with GitHub Pages
1. In the repository, open **Settings > Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
3. After a minute your site is live at `https://<your-username>.github.io/` (or `https://<your-username>.github.io/<repo-name>/` for any other repository name).
