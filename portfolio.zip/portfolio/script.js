/* ===== EDIT YOUR DETAILS HERE ===== */
const CONFIG = {
  email: "",                                   // e.g. "you@example.com"
  github: "",                                  // e.g. "https://github.com/username"
  linkedin: "",                                // e.g. "https://www.linkedin.com/in/username"
  resumePdf: "assets/resume/resume.pdf",
  courseDates: "Start year – Expected graduation year (edit in script.js)"
};
const SKILLS = [
  { icon: "🐍", group: "Programming", items: ["Python", "SQL"] },
  { icon: "🌐", group: "Web development", items: ["HTML", "CSS", "JavaScript", "Flask"] },
  { icon: "📊", group: "Data analytics", items: ["Power BI", "Excel", "Data analysis"] },
  { icon: "🛠️", group: "Tools", items: ["Git", "GitHub", "VS Code", "Google Colab"] }
];
// status: update to "Completed" only when the project is truly finished. repo: paste the GitHub URL when ready.
const PROJECTS = [
  { title: "SmartGymAnalytics", category: "Web app", status: "In progress", repo: "",
    sub: "Personalized fitness and nutrition analytics system for preventive healthcare",
    desc: "A fitness and nutrition web application designed to help users understand their fitness condition through BMI calculations, personalized diet guidance, workout recommendations, and progress tracking.",
    tech: ["Python", "Flask", "SQLite", "HTML", "CSS", "JavaScript"] },
  { title: "Customer Couture Studio", category: "Web app", status: "In progress", repo: "",
    sub: "Personalized fashion e-commerce and garment customization platform",
    desc: "A full-stack fashion e-commerce platform that allows customers to explore fashion products and personalize garment designs.",
    tech: ["Python Flask", "PostgreSQL", "HTML", "CSS", "JavaScript"] },
  { title: "IoT Agriculture Analytics", category: "Data analytics", status: "In progress", repo: "",
    sub: "Farming data analysis and visualization",
    desc: "An agriculture analytics project using a dataset to study farming-related indicators, perform data analysis, and generate meaningful visualizations using Google Colab.",
    tech: ["Python", "Pandas", "NumPy", "Matplotlib", "Google Colab"] },
  { title: "Comparative Speech Recognition Model Evaluation", category: "Research", status: "In progress", repo: "",
    sub: "Comparing four automatic speech recognition models",
    desc: "A research-oriented project focused on comparing four Automatic Speech Recognition models using suitable English speech datasets and evaluation metrics.",
    tech: ["Python", "Whisper", "Transformers", "FFmpeg", "WER"] }
];
/* ===== END OF EDITABLE SECTION ===== */

const $ = (s, r = document) => r.querySelector(s);
const toast = m => { const t = $("#toast"); t.textContent = m; t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 2600); };
const placeholder = v => !v;

// Social and contact links: use placeholders until CONFIG is filled in
document.querySelectorAll("[data-link]").forEach(a => {
  const k = a.dataset.link, v = CONFIG[k];
  if (placeholder(v)) { a.addEventListener("click", e => { e.preventDefault(); toast("Add your " + k + " in script.js (CONFIG)"); }); }
  else a.href = k === "email" ? "mailto:" + v : v;
});

// Skills
$("#skillGrid").innerHTML = SKILLS.map(s => `<div class="card"><h3>${s.icon} ${s.group}</h3><div class="tags">${s.items.map(i => `<span>${i}</span>`).join("")}</div></div>`).join("");
$("#paperSkills").textContent = SKILLS.flatMap(s => s.items).join(", ");
$("#paperProjects").innerHTML = PROJECTS.map(p => `<li><b>${p.title}</b>: ${p.sub} (${p.tech.join(", ")})</li>`).join("");
$("#eduDates").textContent = CONFIG.courseDates;

// Projects with category filter
const cats = ["All", ...new Set(PROJECTS.map(p => p.category))];
$("#filters").innerHTML = cats.map((c, i) => `<button class="${i ? "" : "on"}" data-c="${c}">${c}</button>`).join("");
function drawProjects(cat) {
  $("#projectGrid").innerHTML = PROJECTS.map((p, i) => ({ p, i })).filter(({ p }) => cat === "All" || p.category === cat).map(({ p, i }) => `
    <div class="card"><span class="cat">${p.category}</span><h3>${p.title}</h3><p>${p.sub}</p>
    <div class="tags">${p.tech.map(t => `<span>${t}</span>`).join("")}</div>
    <div class="btns"><a class="btn" data-repo="${i}" target="_blank" rel="noopener">GitHub repository</a><button class="btn" data-i="${i}">Project details</button></div></div>`).join("");
}
drawProjects("All");
$("#filters").addEventListener("click", e => { const b = e.target.closest("button"); if (!b) return; document.querySelectorAll("#filters button").forEach(x => x.classList.toggle("on", x === b)); drawProjects(b.dataset.c); });
$("#projectGrid").addEventListener("click", e => {
  const r = e.target.closest("[data-repo]"), d = e.target.closest("[data-i]");
  if (r) { const p = PROJECTS[r.dataset.repo]; if (p.repo) r.href = p.repo; else { e.preventDefault(); toast("Repository link not added yet"); } }
  if (d) { const p = PROJECTS[d.dataset.i]; $("#modalBody").innerHTML = `<span class="cat">${p.category}</span><h3>${p.title}</h3><p>${p.desc}</p><div class="tags">${p.tech.map(t => `<span>${t}</span>`).join("")}</div><p><b>Status:</b> ${p.status}</p>`; $("#modal").hidden = false; $(".x").focus(); }
});
$("#modal").addEventListener("click", e => { if (e.target.id === "modal" || e.target.closest(".x")) $("#modal").hidden = true; });
document.addEventListener("keydown", e => { if (e.key === "Escape") $("#modal").hidden = true; });

// Resume: download, replace and print
let pdfUrl = CONFIG.resumePdf;
document.querySelectorAll("[data-dl]").forEach(a => a.addEventListener("click", e => {
  if (a.getAttribute("href") === "#resume") return;       // hero button just scrolls to the section
  e.preventDefault(); const l = document.createElement("a"); l.href = pdfUrl; l.download = "Subba_Reddy_Velpula_Resume.pdf"; l.click();
}));
$("#pdfIn").addEventListener("change", e => { const f = e.target.files[0]; if (f && f.type === "application/pdf") { pdfUrl = URL.createObjectURL(f); toast("PDF replaced for this session"); } else toast("Choose a PDF file"); });
$("#printBtn").addEventListener("click", () => { document.body.classList.add("printing"); window.print(); });
window.addEventListener("afterprint", () => document.body.classList.remove("printing"));

// Contact form (no backend): opens the visitor's mail app
$("#form").addEventListener("submit", e => {
  e.preventDefault();
  if (placeholder(CONFIG.email)) return toast("Add your email in script.js (CONFIG)");
  const f = new FormData(e.target);
  location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent("Portfolio message from " + f.get("name"))}&body=${encodeURIComponent(f.get("msg") + "\n\n" + f.get("email"))}`;
});

// Mobile menu, back to top, scroll reveal
const burger = $(".burger"), menu = $("#menu");
burger.addEventListener("click", () => { const o = menu.classList.toggle("open"); burger.setAttribute("aria-expanded", o); });
menu.addEventListener("click", e => { if (e.target.tagName === "A") menu.classList.remove("open"); });
const top = $("#toTop"); top.onclick = () => scrollTo({ top: 0 });
addEventListener("scroll", () => top.hidden = scrollY < 500, { passive: true });
const io = new IntersectionObserver(es => es.forEach(x => { if (x.isIntersecting) { x.target.classList.add("in"); io.unobserve(x.target); } }), { threshold: .1 });
document.querySelectorAll(".reveal").forEach(el => io.observe(el));
$("#yr").textContent = new Date().getFullYear();
